#!/bin/sh
# trigger-run.sh — tao 1 commit moi de kich hoat workflow Gitea Actions (retrigger)
# Chay: cd ~/ci-runner && sh harness/trigger-run.sh
set -u
cd "$(dirname "$0")/.." || exit 1

TOKEN=$(curl -s -u 'mcorp:MegaCorp!2026' -X POST http://localhost:3000/api/v1/users/mcorp/tokens \
  -H 'Content-Type: application/json' -d "{\"name\":\"trig-$(date +%s)\",\"scopes\":[\"all\"]}" \
  | python3 -c 'import sys,json;print(json.load(sys.stdin).get("sha1",""))')
if [ "${#TOKEN}" -ne 40 ]; then
    echo "FATAL: mint token that bai (len=${#TOKEN})"
    exit 1
fi

P=.gitea/workflows/demo.yaml
SHA=$(curl -s -H "Authorization: token $TOKEN" "http://localhost:3000/api/v1/repos/mcorp/demo/contents/$P" \
  | python3 -c 'import sys,json;print(json.load(sys.stdin)["sha"])')

CONTENT=$(printf 'name: demo\non: [push]\njobs:\n  hi:\n    runs-on: ubuntu-latest\n    steps:\n      - run: echo "hello from $(hostname)"; uname -a; id; cat /etc/os-release | head -2\n' | base64 -w0)

CODE=$(curl -s -H "Authorization: token $TOKEN" -H 'Content-Type: application/json' \
  -X PUT "http://localhost:3000/api/v1/repos/mcorp/demo/contents/$P" \
  -d "{\"content\":\"$CONTENT\",\"message\":\"run $(date +%s)\",\"sha\":\"$SHA\"}" \
  -o /dev/null -w '%{http_code}')
echo "trigger HTTP $CODE  (200 = run moi da xep hang)"
echo "theo doi: sudo docker compose logs -f ci-runner"
