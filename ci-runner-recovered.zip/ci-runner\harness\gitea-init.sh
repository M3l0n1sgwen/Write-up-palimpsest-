#!/bin/sh
# gitea-init.sh — chạy trong container gitea (alpine/busybox), sinh registration token.
# Token ghi vào volume /shared/secrets để ci-runner đọc (đúng cơ chế entry.sh).
set -eu

GITEA_URL="${GITEA_URL:-http://gitea:3000}"
TOKEN_FILE="/shared/secrets/act-runner-registration.token"
APP_INI="${GITEA_APP_INI:-/data/gitea/conf/app.ini}"
GITEA_WORK_DIR="${GITEA_WORK_DIR:-/data}"
export GITEA_WORK_DIR

echo "[gitea-init] waiting for ${GITEA_URL}/api/v1/version"
i=0
until wget -q -O /dev/null "${GITEA_URL}/api/v1/version"; do
    i=$((i + 1))
    if [ "$i" -ge 150 ]; then echo "[gitea-init] FATAL: gitea not up"; exit 1; fi
    sleep 2
done

echo "[gitea-init] minting runner registration token (config=${APP_INI})"
mkdir -p /shared/secrets
# gitea CLI phải chạy với user 'git'
su-exec git gitea --config "$APP_INI" actions generate-runner-token > "$TOKEN_FILE"
chmod 0644 "$TOKEN_FILE"

echo "[gitea-init] token -> ${TOKEN_FILE}:"
cat "$TOKEN_FILE"

# (tuỳ chọn) tạo admin để bạn đăng nhập web :3000
# su-exec git gitea --config "$APP_INI" admin user create --admin \
#     --username mcorp --password 'MegaCorp!2026' --email mcorp@megacorp.local --must-change-password=false || true
echo "[gitea-init] done"
