#!/bin/sh
# verify.sh - kiem tra tinh (chay tu bat ky dau, khong hard-code duong dan).
set -u
R="$(cd "$(dirname "$0")/.." && pwd)"      # .../ci-runner

echo "### [0] hash 5 file phuc hoi (RECOVERED.sha256)"
( cd "$R" && sha256sum -c RECOVERED.sha256 2>&1 )

echo
echo "### [1] sh -n (syntax cac script)"
for f in "$R/usr/local/bin/act_runner-entry.sh" "$R/restore.sh" \
         "$R/harness/gitea-init.sh" "$R/harness/local-mock/run-local.sh" \
         "$R/harness/local-mock/cleanup.sh" "$R/harness/local-mock/mock-act_runner" \
         "$R/harness/install-into-rootfs.sh"; do
    if sh -n "$f" 2>/tmp/vs_err; then echo "OK   $(basename "$f")"; else echo "BAD  $(basename "$f"): $(cat /tmp/vs_err)"; fi
done

echo
echo "### [2] python -c compile (unlock.py)"
python3 -m py_compile "$R/harness/unlock.py" && echo "OK   unlock.py"

echo
echo "### [3] systemd-analyze verify act_runner.service"
if command -v systemd-analyze >/dev/null 2>&1; then
    cp "$R/etc/systemd/system/act_runner.service" /tmp/act_runner.service
    systemd-analyze verify /tmp/act_runner.service 2>&1 | sed 's/^/    /'
    echo "    (canh bao docker.service/network-online.target la DUNG neu may chua co)"
else
    echo "    (khong co systemd-analyze -> bo qua)"
fi

echo
echo "### [4] YAML parse docker-compose.yml"
python3 - "$R/harness/docker-compose.yml" <<'PY'
import sys
try:
    import yaml
except ImportError:
    print("    (khong co PyYAML -> bo qua)"); raise SystemExit(0)
d = yaml.safe_load(open(sys.argv[1]))
print("    services:", list(d.get("services", {}).keys()))
print("    volumes :", list(d.get("volumes", {}).keys()))
PY

echo
echo "### [5] file type 2 binary"
if command -v file >/dev/null 2>&1; then file "$R/usr/bin/head" "$R/usr/bin/systemctl"; fi
