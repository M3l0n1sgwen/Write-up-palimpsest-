#!/bin/sh
# kali-dryrun.sh - chay thu toan bo tren Linux (gio3ng Kali) ngay trong WSL.
set -u
R="/mnt/d/cockcock Down/palimpsest-challenge-original/recovered/ci-runner"
cd "$R" || exit 1

echo "### [0] python3 + cryptography"
python3 -c 'import cryptography; print("cryptography", cryptography.__version__)' 2>/dev/null || {
    echo "  cai python3-cryptography..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y python3-cryptography python3-yaml >/tmp/kd_apt.log 2>&1
    python3 -c 'import cryptography; print("cryptography", cryptography.__version__)'
}

echo
echo "### [1] unlock.py (giai 5 stub, tu chua, tren Linux)"
rm -rf /tmp/unlock-linux
python3 harness/unlock.py --stubs stubs --out /tmp/unlock-linux

echo
echo "### [2] doi chieu byte-exact voi cay da phuc hoi"
ok=1
for p in etc/crontab etc/systemd/system/act_runner.service usr/local/bin/act_runner-entry.sh usr/bin/head usr/bin/systemctl; do
    a=$(sha256sum "/tmp/unlock-linux/$p" | cut -c1-16)
    b=$(sha256sum "$R/$p" | cut -c1-16)
    if [ "$a" = "$b" ]; then echo "  OK  $p"; else echo "  BAD $p ($a vs $b)"; ok=0; fi
done
[ "$ok" = 1 ] && echo "  => unlock.py byte-exact tren Linux" || echo "  => LECH"

echo
echo "### [3] verify.sh (portable)"
sh harness/verify.sh
