#!/bin/sh
# run-local.sh — chạy THẬT act_runner-entry.sh (bản đã phục hồi) mà KHÔNG cần Docker.
#
# Cách ly: chỉ giả lập 2 dependency ngoài (gitea HTTP API + binary act_runner).
# Mọi thứ khác (đường dẫn /shared/secrets, /var/lib/actrunner, /etc/actrunner/config.yaml,
# logic chờ API/chờ token/register idempotent/exec daemon) là script gốc, không sửa.
#
# Yêu cầu: Linux/WSL, root, có python3 + curl.
set -eu

HERE="$(cd "$(dirname "$0")" && pwd)"
RECOVERED="$(cd "$HERE/../.." && pwd)"          # recovered/ci-runner
PORT="${PORT:-3939}"

echo "### [1] cài file phục hồi vào ĐÚNG đường dẫn gốc"
install -d /usr/local/bin /etc/actrunner /var/lib/actrunner /shared/secrets
install -m 0755 "$RECOVERED/usr/local/bin/act_runner-entry.sh" /usr/local/bin/act_runner-entry.sh
install -m 0644 "$HERE/../config.yaml" /etc/actrunner/config.yaml
sha256sum /usr/local/bin/act_runner-entry.sh

echo "### [2] mock dependency (act_runner binary + gitea HTTP)"
install -d /opt/ci-mock/bin
install -m 0755 "$HERE/mock-act_runner" /opt/ci-mock/bin/act_runner
rm -f /var/lib/actrunner/.runner /shared/secrets/act-runner-registration.token /tmp/mock-act_runner.log

python3 -m http.server "$PORT" --bind 127.0.0.1 --directory "$HERE/mockgitea" >/tmp/mockgitea.log 2>&1 &
GITEA_PID=$!
trap 'kill $GITEA_PID 2>/dev/null || true' EXIT INT TERM
i=0
until curl -fsS -o /dev/null "http://127.0.0.1:${PORT}/api/v1/version"; do
    i=$((i+1)); [ "$i" -ge 50 ] && { echo "mock gitea không lên"; exit 1; }; sleep 0.2
done
echo "    mock gitea UP (pid $GITEA_PID, :$PORT)"

# token xuất hiện SAU 2s -> kiểm tra nhánh 'chờ token'
( sleep 2; printf 'MOCK-REGISTRATION-TOKEN-abc123\n' > /shared/secrets/act-runner-registration.token ) &

echo
echo "### [3] RUN 1 — lần đầu (phải: chờ API -> chờ token -> register -> daemon)"
PATH="/opt/ci-mock/bin:$PATH" GITEA_INSTANCE_URL="http://127.0.0.1:${PORT}" \
    /usr/local/bin/act_runner-entry.sh > /tmp/run1.log 2>&1
cat /tmp/run1.log

echo
echo "### [4] RUN 2 — chạy lại (phải: 'already registered' -> daemon, KHÔNG register lại)"
PATH="/opt/ci-mock/bin:$PATH" GITEA_INSTANCE_URL="http://127.0.0.1:${PORT}" \
    /usr/local/bin/act_runner-entry.sh > /tmp/run2.log 2>&1
cat /tmp/run2.log

echo
echo "### [5] ASSERT"
rc=0
if [ -s /var/lib/actrunner/.runner ]; then echo "PASS  .runner được tạo"; else echo "FAIL  thiếu .runner"; rc=1; fi
if grep -q 'gitea reachable' /tmp/run1.log; then echo "PASS  chờ API gitea OK"; else echo "FAIL  không thấy 'gitea reachable'"; rc=1; fi
if grep -q 'waiting for registration token' /tmp/run1.log; then echo "PASS  nhánh chờ token"; else echo "FAIL  thiếu nhánh chờ token"; rc=1; fi
if grep -q 'registering runner' /tmp/run1.log; then echo "PASS  gọi register"; else echo "FAIL  không gọi register"; rc=1; fi
if grep -q 'already registered' /tmp/run2.log; then echo "PASS  idempotent (RUN2 skip register)"; else echo "FAIL  RUN2 không idempotent"; rc=1; fi
if [ "$(grep -c 'registering runner' /tmp/run1.log)" -eq 1 ] && [ "$(grep -c 'already registered' /tmp/run2.log)" -eq 1 ]; then
    echo "PASS  chỉ register đúng 1 lần"
else echo "FAIL  số lần register sai"; rc=1; fi

echo
echo "--- /var/lib/actrunner/.runner ---"; cat /var/lib/actrunner/.runner
echo "--- /tmp/mock-act_runner.log ---";  cat /tmp/mock-act_runner.log
echo
[ "$rc" -eq 0 ] && echo "===> TẤT CẢ PASS" || echo "===> CÓ FAIL"
exit "$rc"
