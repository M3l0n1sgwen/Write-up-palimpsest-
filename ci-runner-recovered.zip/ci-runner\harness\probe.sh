#!/bin/sh
# probe.sh - liệt kê tool có sẵn trong WSL để chọn cách mô phỏng.
for t in python3 python busybox nc ncat socat systemctl docker sha256sum file git getent; do
    printf '%-10s %s\n' "$t" "$(command -v "$t" 2>/dev/null || echo MISSING)"
done
echo "--- sh ---"
ls -l /bin/sh
