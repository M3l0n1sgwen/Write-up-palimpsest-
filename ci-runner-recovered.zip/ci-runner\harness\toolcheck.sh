#!/bin/sh
# toolcheck.sh - kiểm tra compiler/openssl trong WSL
echo "--- compilers ---"
for t in gcc cc clang make pkg-config; do
    printf '%-12s %s\n' "$t" "$(command -v "$t" 2>/dev/null || echo MISSING)"
done
echo "--- openssl headers ---"
ls -l /usr/include/openssl/evp.h 2>&1
ls -l /usr/include/openssl/crypto.h 2>&1
echo "--- openssl lib ---"
ls /usr/lib/x86_64-linux-gnu/libcrypto.so* 2>&1
echo "--- pkg-config openssl ---"
pkg-config --modversion openssl 2>&1 || echo "pkg-config: no openssl.pc"
