#!/bin/sh
# check-compose.sh - xac nhan compose o goc + context/dockerfile tro dung
set -u
R="/mnt/d/cockcock Down/palimpsest-challenge-original/recovered/ci-runner"
cd "$R"

echo "### YAML parse + build config"
python3 - <<'PY'
import yaml
d = yaml.safe_load(open("docker-compose.yml"))
print("  name    :", d.get("name"))
print("  services:", list(d["services"]))
b = d["services"]["ci-runner"]["build"]
print("  build   :", b)
import os
ctx = b["context"]
df = os.path.join(ctx, b["dockerfile"])
print("  context exists :", os.path.isdir(ctx))
print("  dockerfile     :", df, "->", os.path.isfile(df))
print("  gitea-init vol :", d["services"]["gitea-init"]["volumes"])
PY

echo
echo "### file Dockerfile can COPY (tinh tu context ci-runner/)"
for f in etc usr RECOVERED.sha256 harness/config.yaml harness/Dockerfile.runner harness/gitea-init.sh; do
    [ -e "$f" ] && echo "  OK   $f" || echo "  MISS $f"
done

echo
echo "### sh -n gitea-init.sh"
sh -n harness/gitea-init.sh && echo "  OK"
