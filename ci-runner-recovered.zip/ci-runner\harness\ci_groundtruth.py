"""
ci_groundtruth.py - Kiem chung 5 stub ci-runner bang CHINH code cua ban to chuc
(generator/package_targets.decrypt_target_stub), co rang buoc path binding.

Dung:
  identity   = tmp/vm-id.bin            (PALID2 TLV, 141 B)
  seal+soul  = opt/palimpsest/frame.bin (PRI1, 48 B)
  digest     = SHA256(opt/palimpsest/progblob.bin) == SHA256(archivist.private.pal)
"""
import os, sys, hashlib

TEAM = r"D:\cockcock Down\palimpsest-team-23"
A    = r"D:\cockcock Down\palimpsest-challenge-original\palimpsest-challenge-original"
sys.path.insert(0, TEAM)
os.chdir(TEAM)

# Ban to chuc chay tren Linux: os.path.normpath("/etc/crontab") == "/etc/crontab".
# Tren Windows no doi thanh "\etc\crontab" -> ep dung posixpath de mo phong Linux.
import posixpath                                                # noqa: E402
os.path.normpath = posixpath.normpath

from generator.package_targets import decrypt_target_stub   # noqa: E402

frame  = open(os.path.join(A, r"opt\palimpsest\frame.bin"), "rb").read()
seal, soul = frame[4:36], frame[36:48]
ident  = open(os.path.join(A, r"tmp\vm-id.bin"), "rb").read()
digest = hashlib.sha256(open(os.path.join(A, r"opt\palimpsest\progblob.bin"), "rb").read()).digest()

print("frame  :", frame[:4], "len", len(frame))
print("seal   :", seal.hex())
print("soul   :", soul.hex())
print("ident  :", ident[:8], "len", len(ident))
print("digest :", digest.hex())
print()

TARGETS = [
    (r"etc\crontab",                                "/etc/crontab"),
    (r"etc\systemd\system\act_runner.service",      "/etc/systemd/system/act_runner.service"),
    (r"usr\local\bin\act_runner-entry.sh",          "/usr/local/bin/act_runner-entry.sh"),
    (r"usr\bin\head",                               "/usr/bin/head"),
    (r"usr\bin\systemctl",                          "/usr/bin/systemctl"),
]

OUT = r"D:\cockcock Down\palimpsest-challenge-original\recovered\ci-runner"
ok_all = True
print("%-42s %-6s %-9s %-8s %s" % ("stub", "mode", "size", "AEAD", "khop out/"))
for rel, path in TARGETS:
    stub = open(os.path.join(A, rel), "rb").read()
    try:
        r = decrypt_target_stub(stub, ident, seal, soul, digest, path=path)
    except Exception as e:
        print("%-42s FAIL: %s" % (rel, e)); ok_all = False; continue
    outp = os.path.join(OUT, path.lstrip("/").replace("/", os.sep))
    same = os.path.exists(outp) and open(outp, "rb").read() == r["data"]
    print("%-42s 0%o  %9d  %-8s %s" % (rel, r["mode"], r["size"], "OK", same))
    ok_all = ok_all and same

# Negative test: sai path -> phai raise
print()
stub = open(os.path.join(A, r"etc\crontab"), "rb").read()
try:
    decrypt_target_stub(stub, ident, seal, soul, digest, path="/etc/wrong")
    print("NEGATIVE-TEST: FAIL (sai path ma van giai duoc)")
    ok_all = False
except Exception as e:
    print("NEGATIVE-TEST: OK  (sai path -> '%s')" % e)

print()
print("===>", "TAT CA DUNG (code ban to chuc xac nhan)" if ok_all else "CO LOI")
sys.exit(0 if ok_all else 1)
