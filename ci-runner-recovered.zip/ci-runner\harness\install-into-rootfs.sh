#!/bin/sh
# install-into-rootfs.sh — cài các artifact ĐÃ PHỤC HỒI vào rootfs Linux thật
# (dùng cho WSL/VM). KHÔNG ghi đè /usr/bin/head, /usr/bin/systemctl, /etc/crontab
# trừ khi bạn truyền --with-system-files (tránh phá hệ thống đang chạy).
set -eu
R="$(cd "$(dirname "$0")/.." && pwd)"     # recovered/ci-runner
WITH_SYSTEM="${1:-}"

echo "### cài entry script + config (file mới, không đè)"
install -d /usr/local/bin /etc/actrunner /var/lib/actrunner /shared/secrets
install -m 0755 "$R/usr/local/bin/act_runner-entry.sh" /usr/local/bin/act_runner-entry.sh
install -m 0644 "$R/harness/config.yaml"               /etc/actrunner/config.yaml
echo "    /usr/local/bin/act_runner-entry.sh  $(sha256sum /usr/local/bin/act_runner-entry.sh | cut -c1-16)…"

echo "### cài unit systemd"
install -d /etc/systemd/system
install -m 0644 "$R/etc/systemd/system/act_runner.service" /etc/systemd/system/act_runner.service
echo "    /etc/systemd/system/act_runner.service"

if [ "$WITH_SYSTEM" = "--with-system-files" ]; then
    echo "### (--with-system-files) backup + ghi đè /etc/crontab, /usr/bin/head, /usr/bin/systemctl"
    for f in etc/crontab usr/bin/head usr/bin/systemctl; do
        case "$f" in etc/*) tgt="/$f";; *) tgt="/$f";; esac
        [ -e "$tgt" ] && cp -a "$tgt" "$tgt.recovered-backup"
    done
    install -m 0644 "$R/etc/crontab"      /etc/crontab
    install -m 0755 "$R/usr/bin/head"     /usr/bin/head
    install -m 0755 "$R/usr/bin/systemctl" /usr/bin/systemctl
fi

echo "### systemd nạp unit"
if command -v systemctl >/dev/null 2>&1 && systemctl is-system-running >/dev/null 2>&1; then
    systemctl daemon-reload
    systemctl cat act_runner.service
    echo "    state: $(systemctl is-enabled act_runner.service 2>/dev/null || echo disabled) / $(systemctl is-active act_runner.service 2>/dev/null || echo inactive)"
else
    echo "    systemd không chạy như PID1 ở đây -> bỏ qua daemon-reload (file vẫn đã được cài)"
fi
echo "### xong"
