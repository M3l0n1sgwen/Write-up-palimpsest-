# Runbook: chạy local trên Kali Linux

Bundle tự chứa: `recovered/ci-runner/` — đã gồm **stub gốc** (`stubs/`) + **vật liệu khoá**
(`keymaterial/`) + file đã phục hồi + harness. Copy nguyên thư mục là chạy được.

```
ci-runner/
├─ docker-compose.yml    # harness "chạy service thật" (project dir = ci-runner/)
├─ etc/  usr/           # 5 file victim ĐÃ phục hồi (byte-exact)
├─ RECOVERED.sha256     # manifest kiểm hash
├─ restore.sh           # cài cây này vào / của một rootfs
├─ keymaterial/         # frame.bin (48B) · vm-id.bin (141B) · progblob.bin (7328B)
├─ stubs/               # 5 stub SBC2026 GỐC (để tự giải lại)
└─ harness/
   ├─ unlock.py                 # giải mã tự chứa (Linux/Win) — không cần source BTC
   ├─ local-mock/run-local.sh   # chạy thật entry.sh bằng mock (KHÔNG cần Docker)
   ├─ install-into-rootfs.sh    # cài service vào /usr/local/bin + /etc/systemd/system
   ├─ Dockerfile.runner         # image cho service "thật" (cần Docker)
   ├─ Dockerfile.job            # image cho JOB container (vá /var/run — xem Gotcha 5)
   ├─ config.yaml               # config act_runner (SYNTHESIZED)
   ├─ gitea-init.sh             # mint registration token
   ├─ trigger-run.sh            # kích hoạt 1 workflow run trên Gitea
   ├─ diagnose-job.sh           # gom log debug khi job fail
   ├─ verify.sh                 # kiểm tra tĩnh
   └─ BTC-SOURCE-ASSESSMENT.md  # đánh giá nguồn ban tổ chức
```

---

## 0. Copy sang Kali

Từ Windows (PowerShell):
```powershell
scp -r "D:\cockcock Down\palimpsest-challenge-original\recovered\ci-runner" kali@<IP_KALI>:~/
```
(Hoặc nén zip → copy qua USB/shared folder rồi giải nén ở `~/ci-runner`.)

## 1. Cài phụ thuộc

```bash
sudo apt update
sudo apt install -y python3 python3-cryptography python3-yaml curl gcc make \
                    libssl-dev libxml2-dev pkg-config
# tuỳ chọn (chỉ khi muốn chạy service thật):
sudo apt install -y docker.io docker-compose-plugin && sudo systemctl enable --now docker
```

## 2. Chọn việc cần chạy

### (A) Chỉ GIẢI MÃ file victim — không cần Docker, không cần root
```bash
cd ~/ci-runner
python3 harness/unlock.py --stubs stubs --out restored
# -> restored/etc/crontab, restored/usr/bin/head, ... (đúng vị trí + quyền gốc)
sha256sum -c RECOVERED.sha256     # đối chiếu: 5/5 OK
```
`unlock.py` tự tìm `keymaterial/`; có thể ghi đè bằng `--frame/--identity/--program`.
Kết quả **byte-exact** với cây đã phục hồi.

### (B) Chạy THỬ service (mock gitea + mock act_runner, KHÔNG cần Docker)
```bash
cd ~/ci-runner
sudo sh harness/local-mock/run-local.sh      # kỳ vọng: PASS 6/6
sudo sh harness/local-mock/cleanup.sh        # gỡ những gì đã cài
```
Cài vào `/usr/local/bin/act_runner-entry.sh`, `/etc/actrunner/config.yaml`, `/opt/ci-mock/...`,
dùng HTTP server `python3` làm Gitea giả.

### (C) Cài service vào rootfs Kali (systemd)
```bash
cd ~/ci-runner
sudo sh harness/install-into-rootfs.sh               # entry.sh + config.yaml + unit systemd
systemctl cat act_runner.service                     # unit nạp được
systemctl status act_runner.service
```
> `systemctl start act_runner.service` sẽ báo **`Unit docker.service not found`** — đúng như thiết kế gốc
> (`Requires=docker.service`). Cài Docker rồi mới start được.
> **KHÔNG** ghi đè `/usr/bin/head`, `/usr/bin/systemctl` của Kali trừ khi bạn chủ động:
> `sudo sh harness/install-into-rootfs.sh --with-system-files` (có backup `.recovered-backup`).

### (D) Chạy service "thật" bằng Docker Compose
`docker-compose.yml` ở **gốc bundle** → chạy thẳng không cần `-f`:
```bash
cd ~/ci-runner
sudo docker compose up --build
# gitea :3000 | gitea-init mint token | job-image build ci-job:bullseye | ci-runner register -> daemon
sudo docker compose down
```
> Nếu bạn lỡ dùng bản cũ `-f harness/docker-compose.yml`, thêm `--project-directory .` để sửa build context.
>
> **Gotcha 1 — build:** `act_runner` asset release KHÔNG có chữ `v` trong tên file
> (`.../download/v0.2.11/act_runner-0.2.11-linux-amd64`), còn tag thì có.
> **Gotcha 2 — token:** `gitea actions generate-runner-token` POST vào
> `setting.LocalURL` = `http://localhost:<port>/` (hard-code loopback), nên service
> `gitea-init` phải dùng `network_mode: "service:gitea"` để chung netns với gitea.
> **Gotcha 3 — job container:** container JOB do act_runner tạo trên docker engine của
> host KHÔNG nằm trong network của compose → `config.yaml` phải đặt
> `container.network: "ci-runner_default"` (= `<project>_default`) để clone được
> `http://gitea:3000`.
> **Gotcha 4 — shell của job:** act_runner chạy step bằng `bash`. Ảnh `*-alpine`
> KHÔNG có bash → `exec: "bash": executable file not found in $PATH`, exit 127.
> Dùng ảnh có bash (`ci-job:bullseye` = `node:18-bullseye` + vá `/var/run`) hoặc thêm
> `defaults: {run: {shell: sh}}` vào workflow.
> **Gotcha 5 — `path escapes from parent` (job fail sau ~0,3 giây, KHÔNG phải treo):**
> act_runner nạp workflow vào container job bằng
> `PUT /containers/<job>/archive?path=/var/run/act` (tarball `workflow/event.json`, `workflow/envs.txt`).
> Trong MỌI image Debian/Ubuntu/Alpine, `/var/run` là **symlink → `/run`**; dockerd (securejoin)
> coi `var/run/act` là "thoát khỏi thư mục cha" nên **từ chối**:
> `failed to copy content to container: Error response from daemon: mkdirat var/run/act: path escapes from parent`.
> Triệu chứng: job log đúng 18 dòng, container job còn sống (`entrypoint=["/bin/sleep","10800"]`),
> `/var/run/act` rỗng. Fix: `harness/Dockerfile.job` biến `/var/run` thành **thư mục thật**
> (service `job-image` build hộ khi `docker compose up --build`).
> **Gotcha 5b — sửa `config.yaml` phải RESTART:** act_runner chỉ đọc config **một lần lúc start**;
> `docker compose up -d` thấy container đang chạy nên không nạp lại ⇒ dùng
> `sudo docker compose restart ci-runner`.
> **Gotcha 5c — thoát hiểm không cần Docker cho job:** đổi label thành `ubuntu-latest:host`
> ⇒ act chạy step ngay trong container `ci-runner` (bỏ hẳn khâu `docker cp`).
Build sẽ cài `act_runner` từ release (không có trong archive) + COPY nguyên bản 5 file victim + tự
`sha256sum -c RECOVERED.sha256` trong image.

### (E) Bắn 1 job thật (chứng minh end-to-end)
Sau khi `ci-runner` đã register + daemon chạy:
```bash
cd ~/ci-runner
sh harness/trigger-run.sh              # tao commit moi -> kich hoat workflow
sleep 45
sudo docker compose logs --tail=20 ci-runner
LAST=$(sudo find /var/lib/docker/volumes/ci-runner_gitea-data/_data/gitea/actions_log \
       -name '*.log' -printf '%T@ %p\n' | sort -n | tail -1 | cut -d' ' -f2-)
sudo cat "$LAST"                       # log job day du (nguon chan ly)
sudo docker ps -a --filter 'name=GITEA-ACTIONS'   # ky vong: RONG (container job da duoc don)
```
Kỳ vọng trong log job: `🚀 Start image=ci-job:bullseye` → `Extracting content to '/var/run/act/'`
→ `⭐ Run Main echo ...` → `hello from <container-id>` → `✅ Success - Main ...` → `🏁 Job succeeded`.
Ảnh job `ci-job:bullseye` = `node:18-bullseye` + vá `/var/run` (Gotcha 5), có `bash`+`git`.
Nếu dùng ảnh `*-alpine` phải thêm `defaults: {run: {shell: sh}}` vào workflow (Gotcha 4).

Nếu job fail, gom bằng chứng bằng: `sudo sh harness/diagnose-job.sh`.

## 3. Kiểm tra tĩnh (tuỳ chọn)
```bash
cd ~/ci-runner && sh harness/verify.sh
# hash OK · sh -n OK · systemd-analyze verify · compose YAML parse · file type
```

---

## Lưu ý

| Điểm | Chi tiết |
|---|---|
| `harness/config.yaml` | **SYNTHESIZED** — `/etc/actrunner/config.yaml` không nằm trong archive |
| `act_runner` binary | không có trong archive → tải ở bước build Docker |
| Đường dẫn | harness dùng **đường dẫn tương đối** — chạy từ đâu cũng được |
| Quyền Unix | trên Windows quyền bị mất; trên Kali giữ đúng `0644/0755` (như header stub) |
| 2 file bootcamp `.enc` | KHÔNG thuộc nhóm này, chưa giải hết (chỉ `palimpsest-team-23/solve/p1_recovered.bin`) |
| Tool C của BTC | build cần `generated_program.h`… không có trong repo → dùng `unlock.py` thay thế |

**Đã kiểm chứng trên Linux thật (WSL Ubuntu 26.04):** `unlock.py` → 5/5 byte-exact · `run-local.sh` → PASS 6/6 ·
`verify.sh` → tất cả OK.
**Đã kiểm chứng end-to-end trên Kali 6.19.14:** stack compose chạy, runner `declare successfully`, và job Gitea
Actions **XANH** — `🏁 Job succeeded` (task 12, container mode: `docker create`/`run`/`exec` + tự dọn
container/volume). Xem §8 của `docs/2026-10-14_re-palimpsest-SOLVED.md` và Gotcha 5 ở trên.
