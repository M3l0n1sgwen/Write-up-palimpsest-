#!/bin/sh
# diagnose-job.sh — gom moi bang chung de tim ly do job dung im sau "task N repo is ..."
# Chay:  cd ~/ci-runner && sudo sh harness/diagnose-job.sh
set -u
cd "$(dirname "$0")/.." || exit 1
GDB=/var/lib/docker/volumes/ci-runner_gitea-data/_data/gitea

echo "=== [0] bat log debug + restart runner ==="
sed -i 's/^  level: info/  level: debug/' harness/config.yaml
grep -n 'level:' harness/config.yaml
docker compose restart ci-runner >/dev/null 2>&1
sleep 3

echo
echo "=== [1] mint token ==="
TOKEN=$(curl -s -u 'mcorp:MegaCorp!2026' -X POST http://localhost:3000/api/v1/users/mcorp/tokens \
  -H 'Content-Type: application/json' -d "{\"name\":\"diag-$(date +%s)\",\"scopes\":[\"all\"]}" \
  | python3 -c 'import sys,json;print(json.load(sys.stdin).get("sha1",""))')
if [ "${#TOKEN}" -ne 40 ]; then echo "FATAL: token mint that bai (len=${#TOKEN})"; exit 1; fi
echo "  token ok (len=${#TOKEN})"

echo
echo "=== [2] trigger 1 run moi ==="
P=.gitea/workflows/demo.yaml
SHA=$(curl -s -H "Authorization: token $TOKEN" "http://localhost:3000/api/v1/repos/mcorp/demo/contents/$P" \
  | python3 -c 'import sys,json;print(json.load(sys.stdin)["sha"])')
CONTENT=$(printf 'name: demo\non: [push]\njobs:\n  hi:\n    runs-on: ubuntu-latest\n    steps:\n      - run: echo "hello from $(hostname)"; uname -a; id\n' | base64 -w0)
CODE=$(curl -s -H "Authorization: token $TOKEN" -H 'Content-Type: application/json' \
  -X PUT "http://localhost:3000/api/v1/repos/mcorp/demo/contents/$P" \
  -d "{\"content\":\"$CONTENT\",\"message\":\"diag $(date +%s)\",\"sha\":\"$SHA\"}" -o /dev/null -w '%{http_code}')
echo "  trigger HTTP $CODE"

echo
echo "=== [3] theo doi container ngoai compose trong 60s ==="
i=0
while [ "$i" -lt 12 ]; do
    sleep 5
    i=$((i + 1))
    EXTRA=$(docker ps -a --format '{{.Names}}|{{.Image}}|{{.Status}}' \
      | grep -v -E '^(ci-runner|gitea|gitea-init)\|' || true)
    if [ -n "$EXTRA" ]; then
        echo "  [t+$((i * 5))s] $EXTRA"
    fi
done
echo "  --- docker ps -a day du ---"
docker ps -a --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}'

echo
echo "=== [4] runner log (toan bo tu lan start moi nhat) ==="
docker compose logs --tail=250 ci-runner

echo
echo "=== [5] action_task trong DB Gitea ==="
rm -f /tmp/_g.db /tmp/_g.db-wal /tmp/_g.db-shm
for f in gitea.db gitea.db-wal gitea.db-shm; do
    [ -f "$GDB/$f" ] && cp "$GDB/$f" "/tmp/_${f#gitea.}" 2>/dev/null
done
python3 - <<'PY'
import sqlite3, os
p = "/tmp/_db" if os.path.exists("/tmp/_db") else "/tmp/_g.db"
try:
    c = sqlite3.connect(p)
    cur = c.execute("select * from action_task order by id desc limit 5")
    cols = [d[0] for d in cur.description]
    print("  cols:", cols)
    for r in cur.fetchall():
        print("  row :", r)
except Exception as e:
    print("  (db read failed:", e, ")")
PY

echo
echo "=== [6] log Gitea ghi cho job (actions_log) ==="
if [ -d "$GDB/actions_log" ]; then
    find "$GDB/actions_log" -type f 2>/dev/null | sort | tail -5
    F=$(find "$GDB/actions_log" -type f 2>/dev/null | sort | tail -1)
    if [ -n "${F:-}" ]; then
        echo "  --- tail '$F' ---"
        case "$(head -c 4 "$F" | od -An -tx1 | tr -d ' \n')" in
            28b52ffd*)
                echo "  (file nen zstd)"
                if command -v zstd >/dev/null 2>&1; then
                    zstd -dc "$F" 2>/dev/null | tail -40
                else
                    echo "  (thieu zstd -> cai: sudo apt-get install -y zstd)"
                fi
                ;;
            *)
                if command -v strings >/dev/null 2>&1; then
                    tail -40 "$F" | strings | tail -40
                else
                    tail -c 4000 "$F" | tr -c '[:print:]\n\t' '.'
                fi
                ;;
        esac
    fi
else
    echo "  (khong co thu muc actions_log)"
fi

echo
echo "=== [7] config.yaml hien hanh ==="
cat harness/config.yaml
echo
echo "=== XONG. (config.yaml dang o muc debug - doi lai '  level: info' khi da xong) ==="
