#!/usr/bin/env python3
"""
unlock.py - Giai ma SBC2026 (victim) -> khoi phuc file goc. Chay duoc tren Linux/macOS/Windows.

Tu chua (self-contained): chi can `cryptography`. Khong phu thuoc source ban to chuc.

  python3 unlock.py --stubs <DIR> --out <DIR>          # quet & giai moi stub trong <DIR>
  python3 unlock.py --stubs . --out ./restored

Vat lieu khoa (mac dinh tim trong ./keymaterial/ hoac ./ ):
  frame.bin   : "PRI1"(4) + seal(32) + soul(12) = 48 B
  vm-id.bin   : identity "PALID2\\0\\0" TLV
  progblob.bin: program (archivist.private.pal); digest = SHA-256(no)

Ghi kieu atomic + phuc hoi mode goc (giong pal_recover_targets cua ban to chuc).
"""
import argparse
import hashlib
import os
import posixpath
import struct
import sys
import zlib

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

MAGIC = b"SBC2026\x00"
HDR = 0x64
TAG = 16
INFO = b"PALINFO-VAULT-v4"


def derive_key(identity: bytes, frame: bytes, program_digest: bytes, salt: bytes) -> bytes:
    if frame[:4] != b"PRI1" or len(frame) != 48:
        raise ValueError("frame phai la 48 B bat dau bang 'PRI1'")
    ikm = (b"PALIKM4" + struct.pack("<H", len(identity)) + identity
           + frame[4:48] + program_digest)
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=salt, info=INFO).derive(ikm)


def decrypt_stub(data: bytes, key: bytes, want_path: str | None = None):
    if data[:8] != MAGIC:
        raise ValueError("khong phai SBC2026")
    ver, cid = data[8], data[9]
    mode = struct.unpack_from("<H", data, 10)[0] & 0o7777
    orig, ctlen = struct.unpack_from("<QQ", data, 12)
    path_hash = data[28:60]
    salt, nonce = data[60:76], data[76:88]
    crc = struct.unpack_from("<I", data, 96)[0]
    if ver != 2 or cid != 1:
        raise ValueError("version/cipher khong ho tro")
    if (zlib.crc32(data[:96]) & 0xFFFFFFFF) != crc:
        raise ValueError("header CRC32 sai")
    if want_path is not None:
        if hashlib.sha256(posixpath.normpath(want_path).encode()).digest() != path_hash:
            raise ValueError("path binding mismatch: %s" % want_path)
    ct = data[HDR:HDR + ctlen]
    tag = data[HDR + ctlen:HDR + ctlen + TAG]
    pt = ChaCha20Poly1305(key).decrypt(nonce, ct + tag, data[:HDR])
    if len(pt) != orig:
        raise ValueError("do dai plaintext sai")
    return mode, pt, salt


def find_keymaterial(roots, args):
    def pick(explicit, *cands):
        if explicit:
            return explicit
        for r in roots:
            for c in cands:
                p = os.path.join(r, c)
                if os.path.isfile(p):
                    return p
        return None
    frame = pick(args.frame, "keymaterial/frame.bin", "frame.bin",
                 "opt/palimpsest/frame.bin")
    ident = pick(args.identity, "keymaterial/vm-id.bin", "vm-id.bin",
                 "keymaterial/identity.bin", "tmp/vm-id.bin")
    prog = pick(args.program, "keymaterial/progblob.bin", "progblob.bin",
                "keymaterial/archivist.private.pal", "opt/palimpsest/progblob.bin")
    return frame, ident, prog


def write_atomic(real_path, payload, mode):
    os.makedirs(os.path.dirname(real_path) or ".", exist_ok=True)
    tmp = "%s.unlock.tmp.%d" % (real_path, os.getpid())
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
    if hasattr(os, "O_BINARY"):
        flags |= os.O_BINARY
    fd = os.open(tmp, flags, 0o600)
    try:
        os.write(fd, payload)
        os.fsync(fd)
    finally:
        os.close(fd)
    os.chmod(tmp, mode)
    os.replace(tmp, real_path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stubs", required=True, help="thu muc chua cac stub (quet de quy)")
    ap.add_argument("--out", required=True, help="thu muc xuat (giu duong dan tuyet doi)")
    ap.add_argument("--root", default=None, help="tien to goc khi stub nam trong sandbox")
    ap.add_argument("--frame"); ap.add_argument("--identity"); ap.add_argument("--program")
    a = ap.parse_args()

    base = os.path.dirname(os.path.abspath(__file__))
    roots = [a.stubs, base, os.path.dirname(base), os.getcwd()]
    frame_p, ident_p, prog_p = find_keymaterial(roots, a)
    for nm, p in (("frame", frame_p), ("identity", ident_p), ("program", prog_p)):
        if not p:
            print("[!] thieu keymaterial: %s" % nm, file=sys.stderr)
            return 2
    frame = open(frame_p, "rb").read()
    identity = open(ident_p, "rb").read()
    digest = hashlib.sha256(open(prog_p, "rb").read()).digest()
    print("[i] frame=%s identity=%s(%dB) digest=%s" %
          (os.path.basename(frame_p), os.path.basename(ident_p), len(identity), digest.hex()[:12]))

    # gom stub
    stubs = []
    for dp, _dn, fn in os.walk(a.stubs):
        for f in fn:
            p = os.path.join(dp, f)
            try:
                with open(p, "rb") as fh:
                    if fh.read(8) == MAGIC:
                        stubs.append(p)
            except OSError:
                pass
    if not stubs:
        print("[!] khong tim thay stub SBC2026 nao trong %s" % a.stubs, file=sys.stderr)
        return 2

    ok = True
    for p in sorted(stubs):
        rel = os.path.relpath(p, a.stubs).replace(os.sep, "/")
        abs_path = "/" + rel
        try:
            data = open(p, "rb").read()
            key = derive_key(identity, frame, digest, data[60:76])
            mode, pt, _salt = decrypt_stub(data, key, want_path=abs_path)
        except Exception as e:
            print("  FAIL %-48s %s" % (rel, e)); ok = False; continue
        real = os.path.join(a.out, rel)
        write_atomic(real, pt, mode)
        print("  OK   %-48s mode=0%o size=%d -> %s" % (rel, mode, len(pt), real))

    print("\n[%s] %d stub" % ("done" if ok else "co loi", len(stubs)))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
