"""
restore_official.py - Dung lai service theo DUNG semantics cua ban to chuc.

Mo phong pal_recover_targets() (runtime/vault_recover.c) bang Python, dung
decrypt_target_stub() cua ban to chuc (generator/package_targets.py):

  * kiem canonical absolute path
  * XAC THUC TAT CA stub truoc (all-or-nothing)
  * ghi kieu atomic: <path>.palimpsest.tmp.<pid> -> fsync -> chmod(mode goc) -> rename
  * mode = header mode & 07777 ; path binding = SHA256(path) khop header offset 0x1C

Cach dung:
  python restore_official.py --root <DIR>          # sandbox (stub nam o <DIR><abspath>)
  python restore_official.py --in-place            # rootfs that (/), CAN root

Vi du sandbox: stub duoc dat vao <DIR>/etc/crontab, <DIR>/usr/bin/head, ...
"""
import argparse
import hashlib
import os
import posixpath
import sys

TEAM = r"D:\cockcock Down\palimpsest-team-23"
ARCH = r"D:\cockcock Down\palimpsest-challenge-original\palimpsest-challenge-original"

sys.path.insert(0, TEAM)
os.chdir(TEAM)
os.path.normpath = posixpath.normpath            # mo phong Linux (tranh bug '\\')

from generator.package_targets import decrypt_target_stub   # noqa: E402

TARGETS = [
    "/etc/crontab",
    "/etc/systemd/system/act_runner.service",
    "/usr/local/bin/act_runner-entry.sh",
    "/usr/bin/head",
    "/usr/bin/systemctl",
]
# stub nguon trong archive (duong dan tuong doi)
STUB_SRC = {
    "/etc/crontab":                                r"etc\crontab",
    "/etc/systemd/system/act_runner.service":      r"etc\systemd\system\act_runner.service",
    "/usr/local/bin/act_runner-entry.sh":          r"usr\local\bin\act_runner-entry.sh",
    "/usr/bin/head":                               r"usr\bin\head",
    "/usr/bin/systemctl":                          r"usr\bin\systemctl",
}


def canonical_absolute_path(p):
    """Ban sao cua canonical_absolute_path() trong vault_recover.c."""
    if not p or len(p) <= 1 or p[0] != "/" or p.endswith("/"):
        return False
    if "//" in p or "/./" in p or "/../" in p:
        return False
    if p.endswith("/.") or p.endswith("/.."):
        return False
    return True


def load_factors():
    frame = open(os.path.join(ARCH, r"opt\palimpsest\frame.bin"), "rb").read()
    assert frame[:4] == b"PRI1" and len(frame) == 48
    seal, soul = frame[4:36], frame[36:48]
    ident = open(os.path.join(ARCH, r"tmp\vm-id.bin"), "rb").read()
    digest = hashlib.sha256(open(os.path.join(ARCH, r"opt\palimpsest\progblob.bin"), "rb").read()).digest()
    return ident, seal, soul, digest


def write_atomic(real_path, data, mode):
    """Ban sao cua write_atomic() trong vault_recover.c (bo fchown khi khong phai root)."""
    tmp = "%s.palimpsest.tmp.%d" % (real_path, os.getpid())
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_BINARY"):
        flags |= os.O_BINARY          # Windows: khong de os.open dich \n -> \r\n
    fd = os.open(tmp, flags, 0o600)
    try:
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)
    os.chmod(tmp, mode)
    os.replace(tmp, real_path)   # POSIX rename() = atomic replace (giong vault_recover.c)
    if os.name == "posix":       # fsync thu muc cha chi co y nghia/tro tren POSIX
        dfd = os.open(os.path.dirname(real_path) or "/", os.O_RDONLY)
        try:
            os.fsync(dfd)
        finally:
            os.close(dfd)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="", help="tien to sandbox ('' = /)")
    ap.add_argument("--in-place", action="store_true", help="ghi vao rootfs that")
    a = ap.parse_args()
    root = "/" if (a.in_place or not a.root) else a.root.rstrip("/")

    ident, seal, soul, digest = load_factors()
    print("[i] identity=%d B  seal=%s  soul=%s  digest=%s" %
          (len(ident), seal[:6].hex(), soul.hex(), digest[:6].hex()))

    # ---- pha 1: XAC THUC TAT CA (all-or-nothing) ----
    items = []
    for p in TARGETS:
        if not canonical_absolute_path(p):
            print("FAIL canonical path:", p); return 2
        real = (root + p) if root not in ("", "/") else p
        if not os.path.isfile(real):
            print("FAIL khong thay stub:", real); return 2
        stub = open(real, "rb").read()
        try:
            r = decrypt_target_stub(stub, ident, seal, soul, digest, path=p)
        except Exception as e:
            print("FAIL xac thuc %s: %s" % (p, e)); return 2
        items.append((p, real, r["data"], r["mode"]))
        print("  OK  %-42s mode=0%o size=%d" % (p, r["mode"], r["size"]))

    # ---- pha 2: GHI (chi khi moi cai da xac thuc) ----
    for p, real, data, mode in items:
        write_atomic(real, data, mode)
        print("  WROTE %s (0%o, %d B)" % (real, mode, len(data)))
    print("[+] dung lai xong: %d file" % len(items))
    return 0


if __name__ == "__main__":
    sys.exit(main())
