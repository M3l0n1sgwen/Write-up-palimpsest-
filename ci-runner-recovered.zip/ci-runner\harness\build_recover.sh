#!/bin/sh
# build_recover.sh - build tool recover CHINH THUC cua ban to chuc tu runtime/*.c.
#
#   sh build_recover.sh <runtime_dir>
#     <runtime_dir> = .../palimpsest-team-23/runtime
#
# LUU Y: se FAIL neu thieu generated_program.h / generated_svg_codec.h /
# generated_arch.h / arch_handlers.c (cac header do pipeline BTC sinh ra,
# KHONG co trong repo). Xem harness/BTC-SOURCE-ASSESSMENT.md.
set -u
SRC="${1:-}"
if [ -z "$SRC" ] || [ ! -d "$SRC" ]; then
    echo "usage: sh $0 <runtime_dir>   (vd: .../palimpsest-team-23/runtime)"; exit 1
fi

B="${TMPDIR:-/tmp}/palbuild"
rm -rf "$B"; mkdir -p "$B"
cp "$SRC"/*.c "$SRC"/*.h "$B"/ 2>/dev/null
cp "$SRC"/../private/generated_*.h "$B"/ 2>/dev/null || true
cp "$SRC"/../private/generated_program.c "$B"/ 2>/dev/null || true
cd "$B"

CFLAGS="$(pkg-config --cflags openssl libxml-2.0 2>/dev/null)"
LIBS="$(pkg-config --libs openssl libxml-2.0 2>/dev/null)"
[ -z "$LIBS" ] && LIBS="-lxml2 -lcrypto"

echo "### build palimpsest-restore (recover_main.c + runtime)"
gcc -Wall -Wextra -O0 -std=c11 -fstack-protector-strong $CFLAGS \
    recover_main.c program.c svg_file.c vm.c host_profile.c host_identity.c vault_recover.c \
    arch_handlers.c generated_program.c -o palimpsest-restore $LIBS -lm 2>&1 | head -30

if [ -x palimpsest-restore ]; then
    echo "### OK -> $B/palimpsest-restore"; file palimpsest-restore
    ./palimpsest-restore 2>&1 | head -3
else
    echo "### BUILD FAILED (thuong do thieu header generated - xem BTC-SOURCE-ASSESSMENT.md)"
    echo "### => dung thay the: python3 harness/unlock.py  (tu chua, khong can build)"
    exit 1
fi
