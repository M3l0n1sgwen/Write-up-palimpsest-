# ci-runner — dựng lại service (recovered)

> Nguồn: `palimpsest-challenge-original` (SBC Arena 2026) — 5 stub SBC2026 v2 đã giải mã,
> khoá dẫn từ `frame = "PRI1"‖seal‖soul` (xem `docs/2026-10-14_re-palimpsest-SOLVED.md`).
> Mọi byte ở đây là **plaintext gốc**, xác thực bằng Poly1305 tag + `path_hash` trong header.

## 1. Service là gì

Máy `ci-runner` (172.16.201.104) chạy một **Gitea Actions runner (`act_runner`)** dưới systemd,
chạy job trong container trên Docker engine của host (`bare metal: no DinD`).
Tên nội bộ: *"MegaCorp Infrastructure CI executor"*. Gitea tại `http://internal-app.megacorp.local:3000`.

Luồng khởi động:

```
systemd (act_runner.service)
   └─ ExecStart=/usr/local/bin/act_runner-entry.sh        (User=root, WorkingDirectory=/var/lib/actrunner)
        ├─ chờ Gitea API /api/v1/version sẵn sàng
        ├─ chờ token đăng ký tại /shared/secrets/act-runner-registration.token
        ├─ act_runner register --instance … --name ci-runner \
        │     --labels ubuntu-latest:docker://node:18-bullseye      (bỏ qua nếu đã có /var/lib/actrunner/.runner)
        └─ exec act_runner daemon --config /etc/actrunner/config.yaml
```

`/etc/crontab` chỉ là crontab Ubuntu chuẩn (`run-parts` hourly/daily/weekly/monthly) — không có job lạ.

`usr/bin/head` và `usr/bin/systemctl` là **binary gốc của Ubuntu** (coreutils / systemd 255),
không bị trojan; chúng chỉ nằm trong danh sách bị mã hoá tại chỗ (victim binaries).

## 2. Cây phục hồi (đúng đường dẫn tuyệt đối gốc)

| File | Mode gốc | Size | SHA-256 plaintext |
|---|---|---|---|
| `etc/crontab` | 0644 | 1136 | `ffb48ad5…969a3` |
| `etc/systemd/system/act_runner.service` | 0644 | 430 | `587f3fc4…b0b30` |
| `usr/local/bin/act_runner-entry.sh` | 0755 | 2082 | `c985a511…830f9` |
| `usr/bin/head` | 0755 | 43528 | `2f990e74…7b83e` |
| `usr/bin/systemctl` | 0755 | 1501304 | `e0d3d0e9…725b` |

Bằng chứng vị trí: header stub (offset `0x1C`) chứa `SHA-256(path)` khớp **chính xác** với
`/etc/crontab`, `/etc/systemd/system/act_runner.service`, `/usr/local/bin/act_runner-entry.sh`,
`/usr/bin/head`, `/usr/bin/systemctl`. Mỗi stub = `100 (header) + plaintext + 16 (tag)`.

## 3. Còn thiếu để chạy thật

5 file trên **không đủ** để service chạy — chúng chưa bao giờ nằm trong archive:

| Cần | Vì sao | Ghi chú |
|---|---|---|
| `act_runner` binary | `entry.sh` gọi trực tiếp | tải từ Gitea release, đặt vào `$PATH` |
| `/etc/actrunner/config.yaml` | `act_runner register/daemon --config` | **không** có trong stub (không bị mã hoá) → phải tạo |
| `/shared/secrets/act-runner-registration.token` | token đăng ký | sinh bằng `gitea actions generate-runner-token` |
| Gitea `internal-app.megacorp.local:3000` | instance + API | |
| Docker engine | `Requires=docker.service`, job chạy container trên host | |
| `/var/lib/actrunner/.runner` | state sau đăng ký (idempotent) | tự sinh khi register |

Thiếu các mục trên thì systemd sẽ fail ở bước chờ token / `act_runner` not found.

## 4. Dùng

```bash
# kiểm hash plaintext
sha256sum -c RECOVERED.sha256

# (tuỳ chọn) cài vào rootfs Linux thật: copy cây này lên /
sudo cp -a etc/. /etc/ && sudo cp -a usr/. /usr/
sudo chmod 0755 /usr/local/bin/act_runner-entry.sh /usr/bin/head /usr/bin/systemctl
sudo systemctl daemon-reload && sudo systemctl enable --now act_runner.service
```

`restore.sh` trong thư mục này làm bước copy+chmod ở trên (chạy trong môi trường Linux/container).

## 5. Dựng lại & chạy thử (harness/)

Xem `harness/README.md`. Hai cách:

- **(b) Local mock** — chạy THẬT `act_runner-entry.sh` đã phục hồi, chỉ thay Gitea API + binary
  `act_runner` bằng mock (không cần Docker). **Đã chạy: PASS 6/6.**
  ```sh
  sudo sh harness/local-mock/run-local.sh
  sudo sh harness/install-into-rootfs.sh   # cài vào /usr/local/bin + /etc/systemd/system
  ```
- **(a) docker-compose** — production-like (gitea + gitea-init + ci-runner, job trên docker.sock host).
  Cần Docker; máy này không có nên chỉ viết + parse YAML.
  ```sh
  docker compose -f harness/docker-compose.yml up --build
  ```

Đã xác nhận trực tiếp: systemd nạp được unit, nhưng `systemctl start act_runner.service` trả
`Unit docker.service not found` — đúng phần "còn thiếu" ở §3.

---

*Mọi ghi chú "synthesized" trong repo này là nội dung tự tạo, KHÔNG phải artifact của challenge.*
