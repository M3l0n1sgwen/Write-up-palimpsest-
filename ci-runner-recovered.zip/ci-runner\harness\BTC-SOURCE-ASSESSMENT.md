# Đánh giá: `palimpsest-team-23` có đủ để dựng lại service ci-runner không?

> Nguồn: `D:\cockcock Down\palimpsest-team-23` (source ban tổ chức) + archive `palimpsest-challenge-original`.
> Ngày: 2026-10-14 · Phạm vi: offline.

## TL;DR

| Việc | Đủ dùng `palimpsest-team-23`? |
|---|---|
| **Kiểm chứng** 5 stub (nội dung + đường dẫn + quyền) | ✅ **Đủ** — bằng chính code BTC (`decrypt_target_stub`) |
| Hiểu **quy trình dựng lại chính thức** | ✅ **Đủ** — `recover_main.c` + `vault_recover.c` |
| **Thực thi** dựng lại (khôi phục tại chỗ, atomic, mode/owner) | ✅ **Đủ về logic** — đã tái lập byte-exact bằng Python của BTC |
| Build tool C `palimpsest-restore` **nguyên trạng** | ❌ **Thiếu** `reference/reference_vm.py` + 4 header generated |
| Payload nguồn của target (`.data`/`.meta.json`) | ❌ **Không có** (deploy qua "Ansible pipeline") |
| `act_runner` binary / `config.yaml` / gitea / docker | ❌ Ngoài phạm vi repo |

**Kết luận:** đủ để **kiểm + tái lập** service; **không** đủ để build lại *nguyên trạng* tool C của BTC, nhưng
không cần — dùng đúng hàm Python của BTC là ra kết quả byte-exact.

---

## 1. Cái repo CHO

### 1.1. Ground truth để kiểm chứng
`generator/package_targets.py`:
- `encrypt_target_stub()` / `decrypt_target_stub()` — định dạng SBC2026 v2 đầy đủ.
- `decrypt_target_stub(..., path=...)` **kiểm luôn `SHA-256(path)` khớp header offset `0x1C`** → xác nhận
  đúng đường dẫn tuyệt đối gốc.

`generator/generate_flag.py::derive_vault_key_v4()` — KDF chuẩn:
```
ikm = "PALIKM4" || u16le(len(identity)) || identity || seal(32) || soul(12) || program_digest(32)
key = HKDF-SHA256(salt=stub.salt, info="PALINFO-VAULT-v4", L=32).derive(ikm)
```
(khớp `sbc2026_decrypt.py` của ta: HKDF block-1 = `HMAC(PRK, "PALINFO-VAULT-v4" || 0x01)`.)

### 1.2. Tool khôi phục chính thức
`runtime/recover_main.c` + `runtime/vault_recover.c`:
```
palimpsest restore <manuscript.svg> <abs-stub> [...]      # đọc frame PRI1 48B từ STDIN
```
Semantics của `pal_recover_targets()`:
1. `canonical_absolute_path()` — chỉ nhận `/abs`, không `//`, `/./`, `/../`, không `/` cuối.
2. **Xác thực TẤT CẢ stub trước** (all-or-nothing) — fail 1 cái là không ghi gì.
3. `write_atomic`: `"<path>.palimpsest.tmp.<pid>"` → `fsync` → `fchown(uid,gid gốc)` → `fchmod(mode gốc)` →
   `rename()` (atomic) → `fsync` thư mục cha.
4. `mode = header.mode & 07777`; `uid/gid` = quyền sở hữu file hiện tại.
5. Giới hạn `path_count ≤ 64`, tổng plaintext ≤ 512 MB.
6. **host-bound**: `host_identity_serialize()` lấy identity của **máy đang chạy**, và `recover_main` còn
   `vm_run(mode=0)` để so `seal` với `factors+4` → chỉ chạy đúng trên box thật (hoặc với host profile khớp).

### 1.3. Lệnh build chính xác
`generator/provision_team.py` L197–217 (`pkg-config openssl libxml-2.0`, `-O0 -std=c11 -fstack-protector-strong`):
```
gcc <cflags> main.c program.c svg_file.c vm.c host_profile.c host_identity.c vault_encrypt.c \
    arch_handlers.c generated_program.c -o palimpsest            <libs> -lm
gcc <cflags> recover_main.c program.c svg_file.c vm.c host_profile.c host_identity.c vault_recover.c \
    arch_handlers.c generated_program.c -o palimpsest-restore    <libs> -lm
```
Sau build, script tự `strip` + kiểm symbol: bản public (`palimpsest`) **phải không chứa** `pal_recover_targets`
/`handle_recover`/`decrypt_item`, bản restore **phải không chứa** `pal_encrypt_targets`/`handle_encrypt`/`encrypt_item`.

---

## 2. Cái repo KHÔNG có (đã kiểm bằng test)

| Thiếu | Bằng chứng |
|---|---|
| `reference/reference_vm.py` | `python -c "import generator.provision_team"` → `ModuleNotFoundError: No module named 'reference.reference_vm'` (dòng `from reference.reference_vm import VMEmulator, HostProvider`) |
| `generated_program.h` / `.c` | `svg_file.c:13: fatal error: generated_program.h: No such file` |
| `generated_svg_codec.h` | `svg_file.c:14` include; sinh bởi `generator/svg_program.py` |
| `generated_arch.h` + `arch_handlers.c` | sinh bởi `generator/generate_arch.py` |
| Payload nguồn target | `provision_team.py` L437: *"SBC2026 target stubs are deployed separately by the Ansible pipeline"*; hoặc `--targets-dir` cặp `*.meta.json` (`{"path","mode"}`) + `*.data` |
| `transcript`/`seal`, `soul` | sinh runtime theo seeds (`soul_seed`); bản deploy nằm ở `tmp/` (do ta thêm) |
| `act_runner` binary, `/etc/actrunner/config.yaml`, gitea, docker | ngoài phạm vi repo |

→ Build C **nguyên trạng** bất khả thi trong repo này; nhưng toàn bộ khoá/định dạng/semantics thì có.

> Lưu ý: `generator/package_targets.py`, `reference/pal_format.py`, `reference/soul_transform.py`,
> `generator/generate_arch.py`, `generator/svg_program.py`, `generator/native_program.py` đều **import OK**.

---

## 3. Kiểm chứng đã chạy

### 3.1. Ground truth (`solve/ci_groundtruth.py`)
Dùng **chính** `decrypt_target_stub` của BTC, có path binding:
```
stub                                       mode   size      AEAD     khop out/
etc\crontab                               0644       1136  OK       True
etc\systemd\system\act_runner.service     0644        430  OK       True
usr\local\bin\act_runner-entry.sh         0755       2082  OK       True
usr\bin\head                              0755      43528  OK       True
usr\bin\systemctl                         0755    1501304  OK       True
NEGATIVE-TEST: OK  (sai path -> 'Stub path binding mismatch')
```
Inputs: `identity = tmp/vm-id.bin` (PALID2, 141 B) · `seal+soul = opt/palimpsest/frame.bin` ·
`program_digest = SHA256(opt/palimpsest/progblob.bin) = 02690ea7…` (== `archivist.private.pal`).

> Bẫy Windows: `os.path.normpath("/etc/crontab")` → `"\etc\crontab"` làm sai path-hash. Ép `posixpath.normpath`
> để mô phỏng Linux (BTC chạy Linux).

### 3.2. Dựng lại byte-exact (`solve/restore_official.py`)
Bản Python mô phỏng **đúng** `pal_recover_targets()` (all-or-nothing + atomic + mode), dùng
`decrypt_target_stub` của BTC. Chạy trên sandbox có stub đặt đúng đường dẫn tuyệt đối:
```
OK  /etc/crontab mode=0644 size=1136 …  WROTE …
…
===> SANDBOX RESTORE == recovered/ci-runner (byte-exact)
etc/crontab                             BYTE-EQUAL  sha=ffb48ad57868ed63
etc/systemd/system/act_runner.service   BYTE-EQUAL  sha=587f3fc4718a766c
usr/local/bin/act_runner-entry.sh       BYTE-EQUAL  sha=c985a5119031dc75
usr/bin/head                            BYTE-EQUAL  sha=2f990e7472d0c4dc
usr/bin/systemctl                       BYTE-EQUAL  sha=e0d3d0e9444da1b2
```
> Bẫy Windows đã xử lý: `os.rename` không ghi đè → `os.replace`; `os.open` text-mode làm `\n`→`\r\n` → thêm
> `O_BINARY`; `fsync` thư mục chỉ có trên POSIX → guard `os.name=="posix"`.

---

## 4. Quy trình dựng lại chính thức (trên box thật)

```sh
# 1) build (trên máy có toolchain + header generated từ pipeline BTC)
gcc -O0 -std=c11 -fstack-protector-strong $(pkg-config --cflags openssl libxml-2.0) \
    recover_main.c program.c svg_file.c vm.c host_profile.c host_identity.c vault_recover.c \
    arch_handlers.c generated_program.c -o palimpsest-restore \
    $(pkg-config --libs openssl libxml-2.0) -lm

# 2) khôi phục (root; frame PRI1 48B qua STDIN; MỘT lần cho tất cả → all-or-nothing)
printf '%s' "$(cat frame.bin)" | sudo ./palimpsest-restore restore /path/archivist.svg \
    /etc/crontab \
    /etc/systemd/system/act_runner.service \
    /usr/local/bin/act_runner-entry.sh \
    /usr/bin/head \
    /usr/bin/systemctl
# -> ghi lại đúng vị trí, đúng mode gốc (0644/0755), atomic
```

Do ràng buộc `vm_run(mode=0)` + `host_identity_serialize()`, tool này **chỉ chạy đúng trên máy ci-runner**
(hoặc khi có host profile khớp). Ngoại tuyến: dùng `solve/restore_official.py` (tương đương, không host-bound).
