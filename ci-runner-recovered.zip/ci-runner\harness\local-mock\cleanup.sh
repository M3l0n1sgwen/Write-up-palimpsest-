#!/bin/sh
# cleanup.sh — gỡ những gì run-local.sh đã cài vào hệ thống.
set -u
rm -f /usr/local/bin/act_runner-entry.sh
rm -rf /etc/actrunner /var/lib/actrunner /opt/ci-mock
rm -f /shared/secrets/act-runner-registration.token
rm -f /tmp/mock-act_runner.log /tmp/mockgitea.log
[ -d /shared/secrets ] && rmdir /shared/secrets 2>/dev/null || true
[ -d /shared ] && rmdir /shared 2>/dev/null || true
echo "[cleanup] done"
