#!/bin/sh
# restore.sh — cài cây ci-runner đã phục hồi vào rootfs Linux thật.
# Chạy trong môi trường Linux (hoặc container có rootfs). Yêu cầu quyền root.
set -eu
ROOT="${1:-/}"
HERE="$(cd "$(dirname "$0")" && pwd)"

echo "[restore] target root: $ROOT"
cp -a "$HERE/etc/." "$ROOT/etc/"
mkdir -p "$ROOT/usr/local/bin"
cp -a "$HERE/usr/local/bin/act_runner-entry.sh" "$ROOT/usr/local/bin/act_runner-entry.sh"
cp -a "$HERE/usr/bin/head"      "$ROOT/usr/bin/head"
cp -a "$HERE/usr/bin/systemctl" "$ROOT/usr/bin/systemctl"

chmod 0644 "$ROOT/etc/crontab" "$ROOT/etc/systemd/system/act_runner.service"
chmod 0755 "$ROOT/usr/local/bin/act_runner-entry.sh" "$ROOT/usr/bin/head" "$ROOT/usr/bin/systemctl"

mkdir -p "$ROOT/var/lib/actrunner" "$ROOT/shared/secrets"
echo "[restore] files installed. Kiểm hash:"
( cd "$HERE" && sha256sum -c RECOVERED.sha256 )
echo "[restore] Bước tiếp theo cần act_runner binary + /etc/actrunner/config.yaml + token (xem README §3)."
