# Harness — "dựng lại service ci-runner"

Hai cách, đúng như đã bàn:

| Cách | File | Chạy được ở đây? | Kết quả |
|---|---|---|---|
| **(b) Local mock** (không cần Docker) | `local-mock/run-local.sh` | ✅ WSL (root, python3+curl) | **6/6 PASS** |
| **(a) docker-compose** (production-like) | `../docker-compose.yml` + `Dockerfile.runner` | ⚠️ cần Docker | đã viết đầy đủ + YAML parse OK |

---

## (b) Local mock — chạy THẬT script phục hồi

Mục tiêu: chứng minh `act_runner-entry.sh` (bản đã giải mã) **hoạt động**, chỉ thay 2 dependency
ngoài (Gitea HTTP API + binary `act_runner` bằng mock). Mọi logic còn lại là script gốc, không sửa.

```sh
sudo sh harness/local-mock/run-local.sh      # PASS 6/6
sudo sh harness/verify.sh                    # sh -n + systemd-analyze + yaml + file
sudo sh harness/install-into-rootfs.sh       # cài vào rootfs thật (/usr/local/bin, /etc/systemd/system)
sudo sh harness/local-mock/cleanup.sh        # gỡ những gì đã cài
```

Kết quả thực tế (`run-local.sh`):

```
PASS  .runner được tạo
PASS  chờ API gitea OK
PASS  nhánh chờ token
PASS  gọi register
PASS  idempotent (RUN2 skip register)
PASS  chỉ register đúng 1 lần
```

Log RUN 1 (nguyên văn script gốc):

```
[act-runner] gitea reachable at http://127.0.0.1:3939
[act-runner] waiting for registration token at /shared/secrets/act-runner-registration.token
[act-runner] registering runner 'ci-runner' (labels: ubuntu-latest:docker://node:18-bullseye)
[act-runner] starting act_runner daemon
```

`act_runner register` nhận đúng tham số gốc:

```
register --no-interactive --config /etc/actrunner/config.yaml \
  --instance http://127.0.0.1:3939 --token MOCK-REGISTRATION-TOKEN-abc123 \
  --name ci-runner --labels ubuntu-latest:docker://node:18-bullseye
```

→ Xác nhận: cơ chế *"chờ API → chờ token ở `/shared/secrets` → register một lần (idempotent qua `.runner`)
→ `exec act_runner daemon`"* là đúng và chạy được.

### Kiểm tra tĩnh (`verify.sh`)
* `sh -n`: 6/6 script OK.
* `systemd-analyze verify`: unit hợp lệ, chỉ thiếu `docker.service` (đúng — harness WSL không có Docker).
* `docker-compose.yml`: parse OK → `services: [gitea, gitea-init, ci-runner]`, `volumes: [gitea-data, actrunner-state]`.
* `file`: `head`/`systemctl` = ELF 64-bit PIE x86-64, dynamically linked, stripped (binary Ubuntu nguyên bản).

### Cài vào rootfs thật (`install-into-rootfs.sh`)
Đã cài: `/usr/local/bin/act_runner-entry.sh`, `/etc/actrunner/config.yaml`,
`/etc/systemd/system/act_runner.service`. systemd đã nạp unit (`systemctl cat act_runner` OK),
state `disabled/inactive`.

`systemctl start act_runner.service` →
```
Failed to start act_runner.service: Unit docker.service not found.
```
→ đúng như phân tích "còn thiếu": unit gốc `Requires=docker.service`. Cờ `--with-system-files` sẽ
ghi đè thêm `/etc/crontab`, `/usr/bin/head`, `/usr/bin/systemctl` (đã backup `.recovered-backup`).

---

## (a) docker-compose — production-like

```
gitea         -> instance (thay internal-app.megacorp.local:3000)
gitea-init    -> mint token: gitea actions generate-runner-token -> /shared/secrets
ci-runner     -> CHÍNH file đã phục hồi; job chạy trên docker engine HOST qua docker.sock (no DinD)
```

`docker-compose.yml` nằm ở **gốc bundle** (để thư mục dự án == `ci-runner/`):

```sh
cd ci-runner
sudo docker compose up --build
```

Dockerfile build: cài `act_runner` (tải release, **không có trong archive**), COPY nguyên bản
`etc/` + `usr/` vào đúng đường dẫn gốc, rồi `sha256sum -c /RECOVERED.sha256` (kiểm tra hash ngay
trong image).

> Không chạy được tại máy này vì **không có Docker**. YAML đã parse OK; `gitea-init.sh` (alpine →
> `su-exec git gitea actions generate-runner-token`) chưa được test runtime.

---

## Thành phần SYNTHESIZED (không thuộc challenge)

| File | Vì sao |
|---|---|
| `harness/config.yaml` | `/etc/actrunner/config.yaml` không nằm trong archive (không bị mã hoá) → phải tạo |
| `harness/mock-act_runner` | thay binary `act_runner` thật khi test logic |
| `harness/mockgitea/` | thay Gitea HTTP API |
| `harness/gitea-init.sh` | sinh token — cơ chế suy ra từ comment trong `entry.sh` |
| `Dockerfile.runner` (bước tải `act_runner`) | binary không có trong archive |
