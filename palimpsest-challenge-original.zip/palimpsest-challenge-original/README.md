# Palimpsest ransomware challenge — original artifacts (SBC Arena 2026)

Capture of the ransomware ("malware recovery") phase artifacts exactly as found on
VM `ci-runner` (172.16.201.104), pulled 2026-09-11 via `pull-payload.sh`
(read-only `cat` over SSH, source: `evidence/ci-runner/opt-mirror/`).

Directory layout mirrors the original absolute paths on the VM:

| File in this archive          | Original path on VM                          | Size     | What it is |
|-------------------------------|----------------------------------------------|----------|------------|
| opt/palimpsest/palimpsest     | /opt/palimpsest/palimpsest                    | 48930016 | Ransomware binary (static ELF, ~48 MB) |
| opt/palimpsest/archivist.svg  | /opt/palimpsest/archivist.svg                 | 784218   | "Manuscript" SVG program shipped with the binary |
| opt/bootcamp/bootcamp-ebpf    | /opt/bootcamp/bootcamp-ebpf                   | 81856    | eBPF monitor component |
| opt/bootcamp/bootcamp-ebpf-selfprotect | /opt/bootcamp/bootcamp-ebpf-selfprotect | 16800 | eBPF self-protect component |
| opt/bootcamp/rules/bootcamp_rules.bin.enc | /opt/bootcamp/rules/bootcamp_rules.bin.enc | 5924016 | Encrypted stub (SBC2026 format) |
| opt/bootcamp/rules/rules.toml.enc | /opt/bootcamp/rules/rules.toml.enc        | 461169   | Encrypted stub (SBC2026 format) |
| etc/crontab                   | /etc/crontab                                  | 1252     | Encrypted stub (SBC2026 format) |
| etc/systemd/system/act_runner.service | /etc/systemd/system/act_runner.service | 546    | Encrypted stub (SBC2026 format) |
| usr/local/bin/act_runner-entry.sh | /usr/local/bin/act_runner-entry.sh        | 2198     | Encrypted stub (SBC2026 format) |
| usr/bin/head                  | /usr/bin/head                                 | 43644    | Encrypted victim binary |
| usr/bin/systemctl             | /usr/bin/systemctl                            | 1501420  | Encrypted victim binary |

All encrypted files start with magic `SBC2026\x00` (stub version 2).

## Integrity

Every file hash matches the hashes captured at pull time in the original
session log (2026-09-11), i.e. none of these files were modified after capture.
See `MANIFEST.sha256`.
